package com.ibm.Learning;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ibm.magentopages.HomePage;
import com.ibm.magentopages.LoginPage;
import com.ibm.magentopages.MyAccountPage;
import com.ibm.utilities.PropertiesFileHandler;

import jdk.nashorn.internal.runtime.PrototypeObject;

public class DataDriven_PageFactory_Test {
	@Test(priority = 3, invocationCount = 1)
	public void PositiveCredentiials() throws IOException {

		String file = "./TestData/magentodata.properties";

		// Location //Properties handler
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data = propFileHandler.getPropertiesAsMap(file);

		String url = data.get("url");
		String userName = data.get("username");
		String password = data.get("password");
		String expectedTitle = data.get("expectedtitle");

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);

		HomePage home = new HomePage(driver);
		home.clickOnMyAccountIcon();

		LoginPage login = new LoginPage(driver, wait);
		login.enterEmailAddress(userName);
		login.enterPassword(password);
		login.clickOnLogin();

		MyAccountPage myAccount = new MyAccountPage(driver, wait);
		String actualTitle = myAccount.getCurrentTitle();

		Assert.assertEquals(actualTitle, expectedTitle);

		myAccount.clickOnLogOut();

	}

	@Test(priority = 2, invocationCount = 1)
	public void NegativeCredentiials() throws IOException {

		String file = "./TestData/magentodata.properties";

		// Location //Properties handler
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data = propFileHandler.getPropertiesAsMap(file);

		String url = data.get("url");
		String userName = data.get("invalidusername");
		String password = data.get("password");
		String expectedTitle = data.get("expectedtitle");

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);

		HomePage home = new HomePage(driver);
		home.clickOnMyAccountIcon();

		LoginPage login = new LoginPage(driver, wait);
		login.enterEmailAddress(userName);
		login.enterPassword(password);
		login.clickOnLogin();

		String pageSource = login.getPageSourceForInvalidErrorMessage();
		Assert.assertTrue(pageSource.contains("Invalid login or password."),
				"Assertion on Invalid login error message");

	}

	@Test(priority = 1, invocationCount = 1)
	public void ForgotPassword() throws IOException {

		String file = "./TestData/magentodata.properties";

		// Location //Properties handler
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data = propFileHandler.getPropertiesAsMap(file);
        
		
		//To get data from the properties file for method created
		String url = data.get("url");
		String email = data.get("email");
		
        //To initialize the wb page
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
		
        //To take the data from home page to click on the MyAccount icon
		HomePage home = new HomePage(driver);
		home.clickOnMyAccountIcon();

		//To perform a click on 'Forgot password' and then click on 'submit' check on the error message and the perform sending email and the click on submit get the invalid message and pass the test case based on that 
		LoginPage login = new LoginPage(driver, wait);
		login.clickOnForgotPassword();
		login.ClickOnSubmit();
		String pageSource1 = login.SubmitButtonFirst();
		Assert.assertTrue(pageSource1.contains("This is a required field."),
				"Assertion on Invalid login error message");
		login.EnterTheEmailAddress(email);
		login.ClickOnSubmit();
		String pageSource2 = login.SubmitButtonError();
		Assert.assertTrue(pageSource2.contains("Please enter a valid email address. For example johndoe@domain.com."),
				"Assertion on Invalid login error message");
	}

}
